import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checksumOf, readMigrations, runMigrations } from '../server/db/migrate.js';

const silent = { log() {}, warn() {}, error() {} };

// Cliente falso: imita lo justo de PostgreSQL (transacciones y la tabla schema_migrations).
function fakeClient({ failOn } = {}) {
  const state = { applied: new Map(), tx: null, executed: [], rollbacks: 0, locks: 0, unlocks: 0 };
  return {
    state,
    async query(text, params = []) {
      const sql = text.trim();
      if (sql.startsWith('SELECT pg_advisory_lock')) { state.locks += 1; return { rows: [] }; }
      if (sql.startsWith('SELECT pg_advisory_unlock')) { state.unlocks += 1; return { rows: [] }; }
      if (sql.startsWith('CREATE TABLE IF NOT EXISTS schema_migrations')) return { rows: [] };
      if (sql.startsWith('SELECT name, checksum FROM schema_migrations')) {
        return { rows: [...state.applied].map(([name, checksum]) => ({ name, checksum })) };
      }
      if (sql === 'BEGIN') { state.tx = new Map(); return { rows: [] }; }
      if (sql === 'COMMIT') { for (const [k, v] of state.tx) state.applied.set(k, v); state.tx = null; return { rows: [] }; }
      if (sql === 'ROLLBACK') { state.tx = null; state.rollbacks += 1; return { rows: [] }; }
      if (sql.startsWith('INSERT INTO schema_migrations')) { state.tx.set(params[0], params[1]); return { rows: [] }; }
      if (failOn && sql.includes(failOn)) throw new Error('boom');
      state.executed.push(sql);
      return { rows: [] };
    },
  };
}

const mig = (name, sql) => ({ name, sql, checksum: checksumOf(sql) });

test('aplica las migraciones en orden y las registra', async () => {
  const c = fakeClient();
  const res = await runMigrations(c, [mig('001_a.sql', 'SELECT 1 -- a'), mig('002_b.sql', 'SELECT 2 -- b')], silent);
  assert.equal(res.applied, 2);
  assert.deepEqual(c.state.executed, ['SELECT 1 -- a', 'SELECT 2 -- b']);
  assert.deepEqual([...c.state.applied.keys()], ['001_a.sql', '002_b.sql']);
});

test('ejecutarla otra vez no repite nada (idempotente)', async () => {
  const c = fakeClient();
  const list = [mig('001_a.sql', 'SELECT 1 -- a')];
  await runMigrations(c, list, silent);
  const second = await runMigrations(c, list, silent);
  assert.equal(second.applied, 0);
  assert.equal(c.state.executed.length, 1);
});

test('solo aplica las nuevas cuando se añade una migración', async () => {
  const c = fakeClient();
  await runMigrations(c, [mig('001_a.sql', 'SELECT 1 -- a')], silent);
  const res = await runMigrations(c, [mig('001_a.sql', 'SELECT 1 -- a'), mig('002_b.sql', 'SELECT 2 -- b')], silent);
  assert.equal(res.applied, 1);
  assert.deepEqual(c.state.executed, ['SELECT 1 -- a', 'SELECT 2 -- b']);
});

test('si una migración falla: ROLLBACK, no se registra, el error nombra la migración y las previas se conservan', async () => {
  const c = fakeClient({ failOn: 'FALLA' });
  await assert.rejects(
    runMigrations(c, [mig('001_a.sql', 'SELECT 1 -- a'), mig('002_mala.sql', 'SELECT FALLA')], silent),
    /Falló la migración 002_mala\.sql: boom/
  );
  assert.equal(c.state.rollbacks, 1);
  assert.deepEqual([...c.state.applied.keys()], ['001_a.sql']);
});

test('detiene el proceso si una migración ya aplicada fue editada', async () => {
  const c = fakeClient();
  await runMigrations(c, [mig('001_a.sql', 'SELECT 1 -- a')], silent);
  await assert.rejects(
    runMigrations(c, [mig('001_a.sql', 'SELECT 1 -- EDITADA')], silent),
    /ya estaba aplicada y su contenido cambió/
  );
});

test('siempre libera el candado, incluso cuando hay error', async () => {
  const ok = fakeClient();
  await runMigrations(ok, [mig('001_a.sql', 'SELECT 1 -- a')], silent);
  assert.equal(ok.state.locks, 1);
  assert.equal(ok.state.unlocks, 1);

  const bad = fakeClient({ failOn: 'FALLA' });
  await assert.rejects(runMigrations(bad, [mig('001_x.sql', 'SELECT FALLA')], silent));
  assert.equal(bad.state.unlocks, 1);
});

test('readMigrations ordena por número, rechaza nombres inválidos y números repetidos', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'mig-'));
  try {
    await writeFile(path.join(dir, '010_diez.sql'), 'SELECT 10;');
    await writeFile(path.join(dir, '002_dos.sql'), 'SELECT 2;');
    await writeFile(path.join(dir, '001_uno.sql'), 'SELECT 1;');
    assert.deepEqual((await readMigrations(dir)).map((m) => m.name), ['001_uno.sql', '002_dos.sql', '010_diez.sql']);

    await writeFile(path.join(dir, 'mala.sql'), 'SELECT 0;');
    await assert.rejects(readMigrations(dir), /inválido/);
    await rm(path.join(dir, 'mala.sql'));

    await writeFile(path.join(dir, '002_otra.sql'), 'SELECT 22;');
    await assert.rejects(readMigrations(dir), /mismo número/);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('la huella es la misma con saltos de línea de Windows o de Linux', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'mig-'));
  try {
    await writeFile(path.join(dir, '001_a.sql'), 'SELECT 1;\r\nSELECT 2;\r\n');
    const [m] = await readMigrations(dir);
    assert.equal(m.checksum, checksumOf('SELECT 1;\nSELECT 2;\n'));
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('la migración real 001 tiene el formato correcto y define las tablas de cuentas', async () => {
  const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '../server/db/migrations');
  const migrations = await readMigrations(dir);
  assert.equal(migrations[0].name, '001_core_accounts.sql');
  const sql = migrations[0].sql;
  const code = sql.replace(/--.*$/gm, ''); // sin comentarios: las reglas se comprueban sobre el SQL real
  for (const needle of ['CREATE TABLE users', 'CREATE TABLE auth_identities', 'CREATE TABLE sessions']) {
    assert.ok(code.includes(needle), `falta: ${needle}`);
  }
  assert.match(code, /CREATE UNIQUE INDEX users_email_lower_key ON users \(lower\(email\)\)/);
  assert.ok(code.includes('password_hash'));
  assert.doesNotMatch(code, /\bpassword\s+text\b/i, 'no debe existir una columna de contraseña en claro');
  assert.doesNotMatch(code, /birth|nacimiento/i, 'no se guarda la fecha de nacimiento');
  // Paréntesis balanceados (revisión básica: aquí no hay PostgreSQL para ejecutarla).
  assert.equal((code.match(/\(/g) || []).length, (code.match(/\)/g) || []).length);
});
