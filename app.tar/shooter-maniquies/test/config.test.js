import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ConfigError, isPooledDatabaseUrl, loadConfig } from '../server/config/index.js';
import { sslOption } from '../server/db/ssl.js';

const base = { DATABASE_URL: 'postgres://usuario:secreto@localhost:5432/juego' };

test('con solo DATABASE_URL usa valores por defecto razonables', () => {
  const c = loadConfig(base);
  assert.equal(c.nodeEnv, 'development');
  assert.equal(c.isProduction, false);
  assert.equal(c.port, 3000);
  assert.equal(c.trustProxy, 0);
  assert.equal(c.databaseSsl, 'disable');
});

test('en producción el SSL hacia la base es "require" por defecto, pero se puede cambiar', () => {
  assert.equal(loadConfig({ ...base, NODE_ENV: 'production' }).databaseSsl, 'require');
  assert.equal(loadConfig({ ...base, NODE_ENV: 'production', DATABASE_SSL: 'disable' }).databaseSsl, 'disable');
});

test('sin DATABASE_URL falla y lo explica', () => {
  assert.throws(() => loadConfig({}), (err) => {
    assert.ok(err instanceof ConfigError);
    assert.match(err.message, /DATABASE_URL es obligatoria/);
    return true;
  });
});

test('una DATABASE_URL inválida falla SIN mostrar su contenido', () => {
  assert.throws(() => loadConfig({ DATABASE_URL: 'http://usuario:secreto@host/db' }), (err) => {
    assert.match(err.message, /postgres:\/\//);
    assert.doesNotMatch(err.message, /secreto/);
    return true;
  });
});

test('PORT, TRUST_PROXY, NODE_ENV y DATABASE_SSL inválidos se rechazan juntos', () => {
  assert.throws(
    () => loadConfig({ ...base, PORT: 'abc', TRUST_PROXY: '99', NODE_ENV: 'prod', DATABASE_SSL: 'si' }),
    (err) => {
      assert.equal(err.problems.length, 4);
      return true;
    }
  );
  assert.throws(() => loadConfig({ ...base, PORT: '70000' }), ConfigError);
  assert.throws(() => loadConfig({ ...base, PORT: '0' }), ConfigError);
});

test('lee PORT y TRUST_PROXY válidos', () => {
  const c = loadConfig({ ...base, PORT: '8080', TRUST_PROXY: '1' });
  assert.equal(c.port, 8080);
  assert.equal(c.trustProxy, 1);
});

test('la configuración resultante es inmutable', () => {
  const c = loadConfig(base);
  assert.throws(() => {
    'use strict';
    c.port = 1;
  }, TypeError);
});

test('sslOption traduce cada modo y rechaza los desconocidos', () => {
  assert.equal(sslOption('disable'), false);
  assert.deepEqual(sslOption('require'), { rejectUnauthorized: true });
  assert.deepEqual(sslOption('no-verify'), { rejectUnauthorized: false });
  assert.throws(() => sslOption('otro'));
});

test('isPooledDatabaseUrl detecta la conexión pooled y deja pasar la directa', () => {
  assert.equal(isPooledDatabaseUrl('postgresql://u:p@ep-cool-123456-pooler.us-west-2.aws.neon.tech/db?sslmode=require'), true);
  assert.equal(isPooledDatabaseUrl('postgresql://u:p@ep-cool-123456.us-west-2.aws.neon.tech/db?sslmode=require'), false);
  assert.equal(isPooledDatabaseUrl('postgres://u:p@localhost:5432/juego'), false);
  assert.equal(isPooledDatabaseUrl('esto no es una url'), false);
});
