// Construye la aplicación Express. No abre puertos ni conexiones: eso lo hace index.js.
import express from 'express';
import helmet from 'helmet';
import { apiNotFound, errorHandler, notFound } from './http/errors.js';
import { gameRouter } from './routes/game.js';
import { healthRouter } from './routes/health.js';

export function createApp({ config, pool, log = console }) {
  const app = express();

  app.disable('x-powered-by');
  // Número de proxies de confianza (0 = ninguno). Importa para la IP real y las cookies seguras.
  app.set('trust proxy', config.trustProxy);

  // Cabeceras de seguridad estándar. La política CSP queda desactivada A PROPÓSITO en esta
  // fase: el HTML del juego usa scripts en línea y todavía no lo hemos tocado. Se activará
  // en la Fase 6 (con nonce), cuando se modifique el HTML para conectarlo con la sesión.
  app.use(helmet({ contentSecurityPolicy: false }));

  app.use('/api/health', healthRouter({ pool, log }));
  app.use('/api', apiNotFound);

  app.use(gameRouter());

  app.use(notFound);
  app.use(errorHandler({ log }));

  return app;
}
