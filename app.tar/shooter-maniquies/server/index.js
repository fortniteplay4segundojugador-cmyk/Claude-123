// Punto de arranque:  npm start
import { ConfigError, loadConfig, loadDotEnv } from './config/index.js';
import { createPool } from './db/pool.js';
import { createApp } from './app.js';

loadDotEnv();

let config;
try {
  config = loadConfig(process.env);
} catch (err) {
  if (err instanceof ConfigError) {
    console.error(err.message);
    process.exit(1);
  }
  throw err;
}

const pool = createPool(config);
const app = createApp({ config, pool });

const server = app.listen(config.port, (err) => {
  if (err) {
    console.error(`[server] no se pudo iniciar: ${err.message}`);
    process.exit(1);
  }
  console.log(`[server] escuchando en el puerto ${config.port} (${config.nodeEnv})`);
});

function shutdown(signal) {
  console.log(`[server] ${signal} recibido: cerrando…`);
  // Si algo se queda colgado, se fuerza la salida a los 10 segundos.
  setTimeout(() => process.exit(1), 10_000).unref();
  server.close(async () => {
    await pool.end();
    process.exit(0);
  });
  server.closeIdleConnections?.();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
