// Lee y valida las variables de entorno UNA sola vez, al arrancar.
// Si falta algo o es inválido, el servidor NO arranca y dice exactamente qué corregir.
// Nunca imprime valores secretos (por ejemplo, la contraseña dentro de DATABASE_URL).

import { existsSync } from 'node:fs';

export class ConfigError extends Error {
  constructor(problems) {
    super(
      'Configuración inválida:\n' +
        problems.map((p) => `  - ${p}`).join('\n') +
        '\nRevisa tu archivo .env (hay un ejemplo en .env.example).'
    );
    this.name = 'ConfigError';
    this.problems = problems;
  }
}

const NODE_ENVS = ['development', 'test', 'production'];
const SSL_MODES = ['disable', 'require', 'no-verify'];

// Carga ".env" si existe (en la nube las variables suelen venir del propio servicio).
// Las variables que ya estén definidas en el entorno tienen prioridad sobre el archivo.
export function loadDotEnv(file = '.env') {
  if (existsSync(file) && typeof process.loadEnvFile === 'function') {
    process.loadEnvFile(file);
  }
}

function parseInteger(raw, { name, min, max, fallback, problems }) {
  if (raw === undefined || raw === '') return fallback;
  if (!/^\d+$/.test(raw)) {
    problems.push(`${name} debe ser un número entero (recibido: "${raw}")`);
    return fallback;
  }
  const n = Number(raw);
  if (n < min || n > max) {
    problems.push(`${name} debe estar entre ${min} y ${max}`);
    return fallback;
  }
  return n;
}

// Proveedores como Neon ofrecen una conexión "pooled" (host con "-pooler") que pasa por un
// intermediario y no conserva el estado de la sesión. Las migraciones usan un candado de sesión,
// así que necesitan la conexión directa.
export function isPooledDatabaseUrl(databaseUrl) {
  try {
    return new URL(databaseUrl).hostname.includes('-pooler');
  } catch {
    return false;
  }
}

export function loadConfig(env = process.env) {
  const problems = [];

  const nodeEnv = env.NODE_ENV || 'development';
  if (!NODE_ENVS.includes(nodeEnv)) {
    problems.push(`NODE_ENV debe ser uno de: ${NODE_ENVS.join(', ')}`);
  }
  const isProduction = nodeEnv === 'production';

  const port = parseInteger(env.PORT, { name: 'PORT', min: 1, max: 65535, fallback: 3000, problems });
  const trustProxy = parseInteger(env.TRUST_PROXY, {
    name: 'TRUST_PROXY',
    min: 0,
    max: 10,
    fallback: 0,
    problems,
  });

  const databaseUrl = env.DATABASE_URL;
  if (!databaseUrl) {
    problems.push('DATABASE_URL es obligatoria (cadena de conexión a PostgreSQL)');
  } else {
    let url = null;
    try {
      url = new URL(databaseUrl);
    } catch {
      // se informa justo debajo, sin mostrar el valor
    }
    if (!url || !['postgres:', 'postgresql:'].includes(url.protocol)) {
      problems.push('DATABASE_URL debe ser una URL que empiece por postgres:// o postgresql://');
    }
  }

  const databaseSsl = env.DATABASE_SSL || (isProduction ? 'require' : 'disable');
  if (!SSL_MODES.includes(databaseSsl)) {
    problems.push(`DATABASE_SSL debe ser uno de: ${SSL_MODES.join(', ')}`);
  }

  if (problems.length > 0) throw new ConfigError(problems);

  return Object.freeze({ nodeEnv, isProduction, port, trustProxy, databaseUrl, databaseSsl });
}
