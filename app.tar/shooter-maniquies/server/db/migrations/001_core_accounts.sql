-- 001_core_accounts.sql
-- Cuentas de jugadores: SOLO identidad y acceso.
--
-- Progreso, estadísticas, inventario, armas, compras, configuraciones y logros
-- irán en tablas propias (migraciones nuevas) con una columna user_id que apunte
-- a users(id). Así esta base no hay que rehacerla para ampliarla.
--
-- Requiere PostgreSQL 13 o superior (gen_random_uuid() viene incluido).
-- Esta migración se ejecuta dentro de una transacción.

-- Mantiene updated_at al día en cualquier tabla que use este trigger.
CREATE FUNCTION set_updated_at() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

-- ---------------------------------------------------------------------------
-- users: la identidad interna del jugador.
--   * password_hash es NULL si la cuenta solo entra con Google.
--   * Nunca se guarda la fecha de nacimiento: solo el resultado de la comprobación
--     de edad y con qué edad mínima se hizo (se rellena en la Fase 4).
--   * El nombre de usuario se añade en la Fase 3, cuando se decida si es único.
-- ---------------------------------------------------------------------------
CREATE TABLE users (
  id                  uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  email               text        NOT NULL,
  password_hash       text,
  age_check_passed_at timestamptz,
  age_check_min_age   smallint,
  status              text        NOT NULL DEFAULT 'active',
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT users_email_not_blank CHECK (btrim(email) <> ''),
  CONSTRAINT users_password_hash_not_blank CHECK (password_hash IS NULL OR password_hash <> ''),
  CONSTRAINT users_status_valid CHECK (status IN ('active', 'disabled')),
  CONSTRAINT users_age_check_complete CHECK ((age_check_passed_at IS NULL) = (age_check_min_age IS NULL)),
  CONSTRAINT users_age_check_min_age_range CHECK (age_check_min_age IS NULL OR age_check_min_age BETWEEN 0 AND 120)
);

-- Correos únicos sin distinguir mayúsculas: "Ana@x.com" y "ana@x.com" son el mismo.
CREATE UNIQUE INDEX users_email_lower_key ON users (lower(email));

CREATE TRIGGER users_set_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- auth_identities: cuentas externas (Google) enlazadas a un usuario interno.
-- Se enlaza por el identificador estable del proveedor ("sub" en Google),
-- nunca por el correo, que puede cambiar.
-- ---------------------------------------------------------------------------
CREATE TABLE auth_identities (
  id                      uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                 uuid        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  provider                text        NOT NULL,
  provider_user_id        text        NOT NULL,
  provider_email          text,
  provider_email_verified boolean,
  created_at              timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT auth_identities_provider_account_key UNIQUE (provider, provider_user_id),
  CONSTRAINT auth_identities_one_per_provider_key UNIQUE (user_id, provider),
  CONSTRAINT auth_identities_not_blank CHECK (btrim(provider) <> '' AND btrim(provider_user_id) <> '')
);

-- ---------------------------------------------------------------------------
-- sessions: sesiones abiertas. El token que viaja en la cookie NUNCA se guarda:
-- aquí solo está su hash SHA-256, así que una filtración de la base no permite
-- usar las sesiones.
-- ---------------------------------------------------------------------------
CREATE TABLE sessions (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  token_hash bytea       NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  CONSTRAINT sessions_token_hash_key UNIQUE (token_hash),
  CONSTRAINT sessions_expires_after_created CHECK (expires_at > created_at)
);

CREATE INDEX sessions_user_id_idx ON sessions (user_id);
CREATE INDEX sessions_expires_at_idx ON sessions (expires_at);
