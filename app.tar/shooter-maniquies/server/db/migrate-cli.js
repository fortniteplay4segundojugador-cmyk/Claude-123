// Uso:  npm run migrate
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ConfigError, isPooledDatabaseUrl, loadConfig, loadDotEnv } from '../config/index.js';
import { createPool } from './pool.js';
import { readMigrations, runMigrations } from './migrate.js';

const MIGRATIONS_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'migrations');

loadDotEnv();

let pool;
try {
  const config = loadConfig(process.env);
  if (isPooledDatabaseUrl(config.databaseUrl)) {
    throw new Error(
      'DATABASE_URL usa la conexión "pooled" (el host contiene "-pooler"). Para migrar hace falta la ' +
        'conexión directa: en Neon, desactiva "Connection pooling" al copiar la cadena de conexión.'
    );
  }
  pool = createPool(config);
  const client = await pool.connect();
  try {
    const migrations = await readMigrations(MIGRATIONS_DIR);
    const { applied } = await runMigrations(client, migrations);
    console.log(applied > 0 ? `[migrate] listo: ${applied} migración(es) aplicada(s).` : '[migrate] la base ya estaba al día.');
  } finally {
    client.release();
  }
} catch (err) {
  console.error(err instanceof ConfigError ? err.message : `[migrate] ${err.message}`);
  process.exitCode = 1;
} finally {
  if (pool) await pool.end();
}
