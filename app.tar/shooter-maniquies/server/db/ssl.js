// Traduce DATABASE_SSL a la opción "ssl" del driver pg.
export function sslOption(mode) {
  if (mode === 'disable') return false;
  if (mode === 'require') return { rejectUnauthorized: true };
  if (mode === 'no-verify') return { rejectUnauthorized: false };
  throw new Error(`Modo SSL desconocido: ${mode}`);
}
