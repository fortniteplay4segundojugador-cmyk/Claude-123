// Conexión a PostgreSQL. Un único pool compartido por todo el servidor.
import pg from 'pg';
import { sslOption } from './ssl.js';

export function createPool(config, log = console) {
  const pool = new pg.Pool({
    connectionString: config.databaseUrl,
    ssl: sslOption(config.databaseSsl),
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000, // tolera que la base "despierte" tras un rato inactiva
  });

  // Un fallo en una conexión inactiva no debe tumbar todo el proceso.
  pool.on('error', (err) => log.error('[db] error en una conexión inactiva:', err.message));

  return pool;
}
