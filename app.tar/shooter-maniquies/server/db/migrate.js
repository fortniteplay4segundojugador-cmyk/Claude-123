// Ejecutor de migraciones SQL.
// - Aplica, en orden numérico, los archivos de ./migrations que aún no estén aplicados.
// - Cada migración corre dentro de una transacción: o se aplica entera o no se aplica.
// - Guarda en la tabla schema_migrations qué se aplicó y una huella (SHA-256) de su contenido.
//   Si una migración ya aplicada se edita después, se detiene con un error claro.
// - Usa un candado de PostgreSQL para que dos procesos no migren a la vez.
import { createHash } from 'node:crypto';
import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';

// Formato obligatorio: 001_descripcion_en_minusculas.sql
const MIGRATION_NAME = /^(\d{3,})_[a-z0-9_]+\.sql$/;

// Número fijo que identifica nuestro candado dentro de PostgreSQL.
const ADVISORY_LOCK_ID = 7_310_001;

export function checksumOf(sql) {
  return createHash('sha256').update(sql).digest('hex');
}

export async function readMigrations(dir) {
  const files = (await readdir(dir)).filter((f) => !f.startsWith('.'));

  const invalid = files.filter((f) => !MIGRATION_NAME.test(f));
  if (invalid.length > 0) {
    throw new Error(
      `Nombre(s) de migración inválido(s): ${invalid.join(', ')}. Usa el formato 001_descripcion.sql`
    );
  }

  const withVersion = files.map((name) => ({ name, version: Number(name.match(MIGRATION_NAME)[1]) }));
  withVersion.sort((a, b) => a.version - b.version);

  for (let i = 1; i < withVersion.length; i += 1) {
    if (withVersion[i].version === withVersion[i - 1].version) {
      throw new Error(`Hay dos migraciones con el mismo número: ${withVersion[i - 1].name} y ${withVersion[i].name}`);
    }
  }

  return Promise.all(
    withVersion.map(async ({ name }) => {
      // Normaliza saltos de línea para que la huella sea igual en Windows y Linux.
      const sql = (await readFile(path.join(dir, name), 'utf8')).replace(/\r\n/g, '\n');
      return { name, sql, checksum: checksumOf(sql) };
    })
  );
}

// "client" debe ser UNA conexión (no el pool): el candado y las transacciones viven en ella.
export async function runMigrations(client, migrations, log = console) {
  await client.query('SELECT pg_advisory_lock($1)', [ADVISORY_LOCK_ID]);
  try {
    await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      name       text        PRIMARY KEY,
      checksum   text        NOT NULL,
      applied_at timestamptz NOT NULL DEFAULT now()
    )`);

    const { rows } = await client.query('SELECT name, checksum FROM schema_migrations');
    const applied = new Map(rows.map((r) => [r.name, r.checksum]));

    for (const m of migrations) {
      const previous = applied.get(m.name);
      if (previous !== undefined && previous !== m.checksum) {
        throw new Error(
          `La migración ${m.name} ya estaba aplicada y su contenido cambió. ` +
            'No se editan migraciones aplicadas: crea una nueva.'
        );
      }
    }

    const onDisk = new Set(migrations.map((m) => m.name));
    for (const name of applied.keys()) {
      if (!onDisk.has(name)) {
        log.warn(`[migrate] aviso: ${name} está aplicada en la base pero no existe en este código.`);
      }
    }

    let count = 0;
    for (const m of migrations) {
      if (applied.has(m.name)) continue;
      log.log(`[migrate] aplicando ${m.name}…`);
      await client.query('BEGIN');
      try {
        await client.query(m.sql);
        await client.query('INSERT INTO schema_migrations (name, checksum) VALUES ($1, $2)', [m.name, m.checksum]);
        await client.query('COMMIT');
      } catch (err) {
        try {
          await client.query('ROLLBACK');
        } catch {
          // la conexión ya estaba rota; el error original es el importante
        }
        throw new Error(`Falló la migración ${m.name}: ${err.message}`, { cause: err });
      }
      count += 1;
    }
    return { applied: count };
  } finally {
    try {
      await client.query('SELECT pg_advisory_unlock($1)', [ADVISORY_LOCK_ID]);
    } catch (err) {
      log.warn('[migrate] no se pudo liberar el candado:', err.message);
    }
  }
}
