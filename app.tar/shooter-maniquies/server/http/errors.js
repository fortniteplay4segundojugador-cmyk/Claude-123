// Respuestas de error uniformes. Nunca se envía al navegador el detalle interno del fallo.

export function apiNotFound(req, res) {
  res.status(404).json({ error: 'not_found' });
}

export function notFound(req, res) {
  res.status(404).type('text/plain').send('No encontrado');
}

export function errorHandler({ log = console } = {}) {
  // Express reconoce un manejador de errores porque tiene EXACTAMENTE 4 parámetros.
  return (err, req, res, next) => {
    if (res.headersSent) return next(err);

    const status = Number.isInteger(err?.status) ? err.status : 500;
    if (status >= 400 && status < 500) {
      res.status(status).json({ error: 'bad_request' });
      return undefined;
    }

    log.error('[http] error no controlado:', err);
    res.status(500).json({ error: 'internal_error' });
    return undefined;
  };
}
