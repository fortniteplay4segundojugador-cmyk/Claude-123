// GET /api/health — para comprobar que el servidor y la base de datos responden.
// Solo dice "ok" o "degraded": no revela versiones, rutas ni datos internos.
import express from 'express';

export function healthRouter({ pool, log = console }) {
  const router = express.Router();

  router.get('/', async (req, res) => {
    res.set('Cache-Control', 'no-store');
    try {
      await pool.query('SELECT 1');
      res.json({ status: 'ok', database: 'ok' });
    } catch (err) {
      log.error('[health] la base de datos no responde:', err.message);
      res.status(503).json({ status: 'degraded', database: 'error' });
    }
  });

  return router;
}
