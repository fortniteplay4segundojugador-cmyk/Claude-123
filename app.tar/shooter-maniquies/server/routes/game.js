// Sirve el juego en "/".
//
// El HTML del juego vive en ./game, FUERA de cualquier carpeta pública, a propósito:
// así, en la Fase 6, solo se podrá abrir pasando por esta ruta, que comprobará la sesión.
// En esta fase el archivo se sirve tal cual, sin modificar un solo byte.
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';

const GAME_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../game');

export function gameRouter() {
  const router = express.Router();

  router.get('/', (req, res, next) => {
    res.set('Cache-Control', 'no-cache');
    res.sendFile('index.html', { root: GAME_DIR }, (err) => {
      if (err && !res.headersSent) next(err);
    });
  });

  return router;
}
