# Shooter de Maniquíes — servidor

Servidor Node.js + Express + PostgreSQL que sirve el juego y, en las fases siguientes, gestionará las cuentas de jugadores.

**Estado: Fase 2 (backend y base de datos) + paquete de despliegue en Render y Neon.** El juego se sirve tal cual: `game/index.html` es idéntico, byte a byte, a `shooter_maniquies_revolver-6_menu_inicio.html` (SHA-256 `d758907d8e56d7379b576878e7a197b05bbb72378b7aa7badb652a95f27f9c0b`). Todavía NO hay registro, inicio de sesión ni sesiones.

## Estructura

```
game/index.html          El juego, sin modificar. Se sirve en "/"
server/
  index.js               Arranque (npm start)
  app.js                 Construye la app Express
  config/index.js        Lee y valida las variables de entorno
  db/
    pool.js, ssl.js      Conexión a PostgreSQL
    migrate.js           Ejecutor de migraciones
    migrate-cli.js       npm run migrate
    migrations/          Archivos SQL numerados (001_..., 002_...)
  http/errors.js         Respuestas de error uniformes
  routes/health.js       GET /api/health
  routes/game.js         GET /  (aquí se comprobará la sesión en la Fase 6)
test/                    Pruebas (npm test)
```

El juego está en `game/` y no en una carpeta pública a propósito: en la Fase 6 solo se podrá abrir pasando por la ruta que comprueba la sesión. Para actualizar el juego, reemplaza `game/index.html`.

## Requisitos

- Node.js 20.12 o superior
- PostgreSQL 13 o superior

## Puesta en marcha en tu equipo

```
cp .env.example .env      # y edita DATABASE_URL
npm install
npm run migrate           # crea las tablas
npm start
```

Abre `http://localhost:3000` (el juego) y `http://localhost:3000/api/health`, que debe responder `{"status":"ok","database":"ok"}`.

## Publicarlo en la nube (Render + Neon, plan gratis para probar)

- **Base de datos (Neon):** crea un proyecto y copia la cadena de conexión **directa**: el host NO debe contener `-pooler` (en el diálogo *Connect*, desactiva *Connection pooling*). `npm run migrate` se niega a funcionar con la cadena pooled porque usa un candado de sesión.
- **Servidor (Render):** el archivo `render.yaml` (en la raíz del repositorio, junto a `app.tar`) crea el servicio con el plan gratis, `NODE_ENV=production`, `TRUST_PROXY=1` y te pide `DATABASE_URL`. Su comando de inicio es `npm run migrate && npm start`.
- **Atajo de subida:** como el repositorio se llena desde el navegador del celular (que solo sube archivos sueltos), todo el proyecto viaja en un único archivo, `app.tar`, que Render extrae al construir. Es un atajo temporal: con una computadora (o con GitHub conectado a Claude) se pasa a un repositorio normal.
- Para actualizar: sube de nuevo `app.tar` al repositorio (mismo nombre, reemplaza el anterior) y Render vuelve a desplegar.
- El plan gratis de Render se duerme tras 15 minutos sin visitas; la primera visita después tarda.

## Variables de entorno

| Variable | Obligatoria | Qué hace |
|---|---|---|
| `DATABASE_URL` | Sí | Conexión a PostgreSQL (en Neon, la directa, sin `-pooler`) |
| `DATABASE_SSL` | No | `disable`, `require` o `no-verify`. Por defecto: `disable` en desarrollo, `require` en producción |
| `PORT` | No | Puerto (3000 por defecto) |
| `TRUST_PROXY` | No | Nº de proxies delante del servidor (0 por defecto) |
| `NODE_ENV` | No | `development`, `test` o `production` |

Si falta algo o es inválido, el servidor no arranca y explica qué corregir sin mostrar secretos. `MIN_AGE` (Fase 4) y las credenciales de Google (Fase 5) se añadirán en su fase.

## Base de datos

Tablas actuales (`server/db/migrations/001_core_accounts.sql`):

- `users`: identidad del jugador. Correo único sin distinguir mayúsculas, hash de contraseña (vacío si solo entra con Google), resultado de la comprobación de edad (nunca la fecha de nacimiento) y estado de la cuenta.
- `auth_identities`: cuentas de Google enlazadas a un usuario, por el identificador estable de Google y no por el correo.
- `sessions`: sesiones abiertas. Solo se guarda el hash del token de la cookie.

Para ampliar (progreso, estadísticas, inventario, armas, compras, configuraciones, logros…): crea un archivo nuevo `00N_descripcion.sql` en `server/db/migrations/`, con la tabla nueva apuntando al jugador con `user_id uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE`, y ejecuta `npm run migrate`. **Nunca edites una migración ya aplicada**: el ejecutor lo detecta (guarda una huella de cada una) y se detiene.

## Seguridad en esta fase

Ya está: secretos solo en variables de entorno (`.env` ignorado por git), cabeceras de seguridad con `helmet`, sin `X-Powered-By`, errores sin detalles internos y comprobación de salud sin datos sensibles.

Falta, y está planificado: hash de contraseñas y límite de intentos (Fase 3), sesiones y protección CSRF (Fases 3 y 6) y política CSP (Fase 6, porque requiere añadir `nonce` al HTML del juego).

## Pruebas

`npm test` (solo necesita Node, no hace falta `npm install`). Cubre la validación de configuración y el ejecutor de migraciones con un cliente de base de datos simulado.

**Aún sin ejecutar:** el SQL contra un PostgreSQL real y el servidor con Express real (el entorno donde se desarrolló no tenía internet ni PostgreSQL). Es lo primero que hay que comprobar en tu primer arranque; si algo falla, copia el mensaje de error completo.
